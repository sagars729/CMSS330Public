git pull public master:public
git checkout master
git pull origin master
git merge --no-ff public
